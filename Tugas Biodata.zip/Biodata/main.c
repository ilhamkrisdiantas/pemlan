#include <stdio.h>
#include <stdlib.h>
#include<windows.h>

int main() {
	
	char nama;
	char ultah;
	char alamat;
	char cita;
	int hp;
	int telp;
	
	printf("============================================\n");
	printf("Isi Data Berikut !\n");
	printf("============================================\n");
	printf(" ");
	printf("Nama Lengkap	:");
	scanf("%s",&nama);
	
	printf("Alamat Rumah	: ");
	scanf("%s",&alamat);
	
	printf("Cita-Cita	: ");
	scanf("%s",&cita);
	
	printf("Tanggal Lahir	: ");
	scanf("%s",&ultah);
	
	printf("Telp Rumah	: ");
	scanf("%d",&telp);
	
	printf("Nomor HP	: ");
	scanf("%d",&hp);
	
	printf(" ");
	printf("============================================\n");
	printf(" ");
	printf("Loading\n");
	printf("\n");
	
	Sleep(2000);
	printf("Sabar");
	Sleep(1000);
	
	printf("Data Biodata Anda");
	printf("\n");
	
	printf("Nama Lengkap	: %s\n",nama);
	printf("Tanggal Lahir	: %s\n",ultah);
	printf("Alamat Rumah	: %s\n",alamat);
	printf("Telp Rumah	: %d\n",telp);
	printf("Cita-Cita	: %s\n",cita);
	printf("Nomor HP	: %d\n",hp);
	
	printf("Mahasiswa UPN Veteran Jawa Timur \n");
	
	Sleep(2000);
	printf("\n");
	
	printf("SUKSES");
	
	
	return 0;
}
